﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using User_inventory.Models;
using User_inventory.Services;

namespace User_inventory.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class UserController : ControllerBase
    {

        private IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("userAdd")]
        public ActionResult<List<User>> UserAdd(User newUser)
        {
            return Ok(_userService.UserAdd(newUser));
        }

        [HttpGet("{id}")]
        public ActionResult <User> UserGet(int id)
        {
            return Ok(_userService.UserGet(int id));
        }

        [HttpGet("userGetAll")]
        public ActionResult <List<User>> UserGetAll()
        {
            return Ok(_userService.UserGetAll());
        }

        [HttpPut("userUpdate")]
        public ActionResult UserUpdate(User newUser)
        {
            return Ok(_userService.UserUpdate());
        }

        [HttpDelete("{id}")]
        public ActionResult UserDelete(int id)
        {
            return Ok();
        }

    }
}
