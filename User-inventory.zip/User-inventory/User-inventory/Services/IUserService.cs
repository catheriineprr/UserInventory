﻿using User_inventory.Models;

namespace User_inventory.Services
{
    public interface IUserService
    {
        List<User> UserAdd(User newUser);
        List<User> UserGetAll();
        User UserGet(int id);
        void UserUpdate(User newUser);

    }
}
