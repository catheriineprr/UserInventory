﻿using Microsoft.AspNetCore.Mvc;
using User_inventory.Models;

namespace User_inventory.Services
{
    public class UserService : IUserService
    {
        private static List<User> users = new List<User>();
      
        public List<User> UserAdd(User newUser)
        {
            users.Add(newUser);
            return users;
        }

        public List<User> UserGetAll()
        {
            return users;
        }

        public User UserGet (int id)
        {
            users.FirstOrDefault(u => u.Id == id);
            return (users[0]);
        }

        public void UserUpdate(User newUser)
        {
            User userUpdated = new User();
            foreach (User user in users)
            {
                if (user.Id == user.Id)
                {
                    user.Name = user.Name;
                    user.Email = user.Email;
                    user.Phone = user.Phone;
                    userUpdated = user;
                }
            }
        }
    }
}
